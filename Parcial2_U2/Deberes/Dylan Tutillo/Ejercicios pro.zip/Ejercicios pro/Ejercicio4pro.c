#include <stdio.h>

int main() {
    float X;

    // Leer n�mero real
    printf("Ingresa un n�mero real: ");
    scanf("%f", &X);

    // Verificar si pertenece al intervalo (0, 10]
    if (X > 0 && X <= 10) {
        printf("El numero pertenece al intervalo (0,10]\n");
    } else {
        printf("El numero NO pertenece al intervalo\n");
    }

    return 0;
}
