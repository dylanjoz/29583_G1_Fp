#include <stdio.h>

int main() {
    // Declaraci�n de variables
    int X;
    int J;
    int Res;

    // Pedir valores al usuario
    printf("Ingresa el primer n�mero X: ");
    scanf("%d", &X);

    printf("Ingresa el segundo n�mero J: ");
    scanf("%d", &J);

    // Calcular el residuo
    Res = X % J;

    // Condici�n para verificar si es divisible
    if (Res == 0) {
        printf("Si es divisible\n");
    } else {
        printf("No es divisible\n");
    }

    return 0;
}
