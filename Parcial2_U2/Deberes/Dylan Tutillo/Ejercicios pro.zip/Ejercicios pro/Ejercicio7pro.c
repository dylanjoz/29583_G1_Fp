#include <stdio.h>

int main() {
    // Variables
    float altura;
    float suma = 0;
    float max, min;
    int contador = 0;

    printf("Ingresa alturas (negativa para terminar):\n");

    // Leer la primera altura fuera del bucle para inicializar min y max
    printf("Altura: ");
    scanf("%f", &altura);

    if (altura >= 0) {
        max = altura;
        min = altura;
        suma = altura;
        contador = 1;
    }

    // Bucle para seguir leyendo alturas
    while (altura >= 0) {
        printf("Altura: ");
        scanf("%f", &altura);

        if (altura >= 0) {
            suma += altura;
            contador++;

            if (altura > max) max = altura;
            if (altura < min) min = altura;
        }
    }

    // Mostrar resultados
    if (contador > 0) {
        printf("Media: %f\n", suma / contador);
        printf("Maximo: %f\n", max);
        printf("Minimo: %f\n", min);
    } else {
        printf("No se ingresaron alturas validas.\n");
    }

    return 0;
}
