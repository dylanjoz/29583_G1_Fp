#include <stdio.h>

int main() {
    // Variables
    int N, R = 0;

    // Leer n�mero
    printf("Ingresa un numero entero positivo: ");
    scanf("%d", &N);

    // Calcular la ra�z cuadrada entera por defecto
    while ((R + 1) * (R + 1) <= N) {
        R++;
    }

    // Resultado
    printf("La raiz cuadrada entera por defecto es: %d\n", R);

    return 0;
}
