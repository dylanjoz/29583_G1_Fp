#include <stdio.h>
#include <math.h>   // Para pow()

int main() {
    // Declarar variables
    float X;
    float Res;
    int C;

    C = 3;

    // Introducir X
    printf("Ingresa n�mero real: ");
    scanf("%f", &X);

    // Operaci�n para encontrar Res
    Res = pow(X, C);

    printf("El valor X elevado al cubo es: %f\n", Res);

    return 0;
}
