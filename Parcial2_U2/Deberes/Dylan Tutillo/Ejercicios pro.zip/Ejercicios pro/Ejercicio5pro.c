#include <stdio.h>

int main() {
    // Variables
    int X, dias, horas, minutos, segundos;

    // Leer segundos
    printf("Ingresa el numero de segundos: ");
    scanf("%d", &X);

    // C�lculos
    dias = X / 86400;
    X = X % 86400;

    horas = X / 3600;
    X = X % 3600;

    minutos = X / 60;
    segundos = X % 60;

    // Resultados
    printf("Dias: %d\n", dias);
    printf("Horas: %d\n", horas);
    printf("Minutos: %d\n", minutos);
    printf("Segundos: %d\n", segundos);

    return 0;
}
