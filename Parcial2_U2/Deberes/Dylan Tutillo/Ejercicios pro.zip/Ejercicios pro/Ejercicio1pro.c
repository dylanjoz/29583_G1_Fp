#include <stdio.h>

int main() {
    // Declaraci�n de variables
    float X;
    float J;
    float RES;
    int C;

    C = 2;

    // Procedimiento e ingreso de variables
    printf("Ingresa primer n�mero real por teclado: ");
    scanf("%f", &X);

    printf("Ingresa segundo n�mero real por teclado: ");
    scanf("%f", &J);

    RES = (X + J) / C;

    printf("La media de los dos numeros es: %f\n", RES);

}

