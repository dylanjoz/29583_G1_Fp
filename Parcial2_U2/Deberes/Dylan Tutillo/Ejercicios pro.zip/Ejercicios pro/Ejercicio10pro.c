#include <stdio.h>

int main() {
    int a, b;
    int i, j;
    int esPrimo;

    // Leer los dos n�meros
    printf("Ingresa el primer numero entero: ");
    scanf("%d", &a);

    printf("Ingresa el segundo numero entero: ");
    scanf("%d", &b);

    // Asegurar que a sea el menor
    if (a > b) {
        int temp = a;
        a = b;
        b = temp;
    }

    printf("Numeros primos entre %d y %d:\n", a, b);

    // Recorrer desde a hasta b
    for (i = a; i <= b; i++) {

        if (i < 2)
            continue; // Los menores que 2 no son primos

        esPrimo = 1;  // Suponemos que es primo

        // Comprobar si i es primo
        for (j = 2; j <= i / 2; j++) {
            if (i % j == 0) {
                esPrimo = 0;
                break;
            }
        }

        if (esPrimo == 1)
            printf("%d ", i);
    }

    printf("\n");
    return 0;
}
