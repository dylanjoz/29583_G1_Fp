#include <stdio.h>

int main() {
    int N, i;
    int esPrimo = 1;   // 1 = s� es primo, 0 = no es primo

    // Leer n�mero
    printf("Ingresa un numero entero mayor que 1: ");
    scanf("%d", &N);

    // Verificar si es primo
    for (i = 2; i <= N / 2; i++) {
        if (N % i == 0) {
            esPrimo = 0;
            break;
        }
    }

    // Resultado
    if (esPrimo == 1)
        printf("El numero es primo.\n");
    else
        printf("El numero NO es primo.\n");

    return 0;
}
