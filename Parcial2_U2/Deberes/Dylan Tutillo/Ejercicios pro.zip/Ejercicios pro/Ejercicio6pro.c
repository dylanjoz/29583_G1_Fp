#include <stdio.h>

int main() {
    // Variables
    float num, suma = 0;
    int contador = 0;
    int i = 1;

    // Leer 3 n�meros reales
    while (i <= 3) {
        printf("Ingresa un numero real: ");
        scanf("%f", &num);

        // Sumar solo si es positivo
        if (num > 0) {
            suma += num;
            contador++;
        }

        i++;
    }

    // Mostrar la media si hubo positivos
    if (contador > 0) {
        printf("La media de los numeros positivos es: %f\n", suma / contador);
    } else {
        printf("No se ingresaron numeros positivos.\n");
    }

    return 0;
}
